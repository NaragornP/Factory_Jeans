-- Status:22:43:MP_0:factoryjeans:php:1.24.4:factoryj:5.7.10-log:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|calico|1|16384||InnoDB
-- TABLE|calico_out|0|16384||InnoDB
-- TABLE|dai|1|16384||InnoDB
-- TABLE|dai_out|0|16384||InnoDB
-- TABLE|fortnight|1|2116|2016-05-16 21:25:08|MyISAM
-- TABLE|gender|2|16384||InnoDB
-- TABLE|jeans|1|16384||InnoDB
-- TABLE|jeans_out|0|16384||InnoDB
-- TABLE|leather|1|16384||InnoDB
-- TABLE|leather_out|0|16384||InnoDB
-- TABLE|ordersell|3|16384||InnoDB
-- TABLE|pants|4|2396|2016-05-16 21:25:11|MyISAM
-- TABLE|sell_pants|6|16384||InnoDB
-- TABLE|sell_pantsprice|6|16384||InnoDB
-- TABLE|shop|6|16384||InnoDB
-- TABLE|studs|1|16384||InnoDB
-- TABLE|studs_out|0|16384||InnoDB
-- TABLE|tag_paper|1|2148|2016-05-16 21:25:14|MyISAM
-- TABLE|tag_paper_out|0|16384||InnoDB
-- TABLE|type_pants|8|16384||InnoDB
-- TABLE|zip|1|16384||InnoDB
-- TABLE|zip_out|0|16384||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2016-05-16 17:23

--
-- Create Table `calico`
--

DROP TABLE IF EXISTS `calico`;
CREATE TABLE `calico` (
  `id_autoca` int(100) NOT NULL AUTO_INCREMENT,
  `ca_code` varchar(255) NOT NULL,
  `ca_yard` int(200) NOT NULL,
  `ca_from` varchar(255) NOT NULL,
  `ca_color` varchar(150) NOT NULL,
  `ca_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autoca`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='ผ้าดิบ';

--
-- Data for Table `calico`
--

/*!40000 ALTER TABLE `calico` DISABLE KEYS */;
INSERT INTO `calico` (`id_autoca`,`ca_code`,`ca_yard`,`ca_from`,`ca_color`,`ca_date`) VALUES ('1','dip77','120','kkkk','','2016/05/03 09:31');
/*!40000 ALTER TABLE `calico` ENABLE KEYS */;


--
-- Create Table `calico_out`
--

DROP TABLE IF EXISTS `calico_out`;
CREATE TABLE `calico_out` (
  `id_autocao` int(100) NOT NULL AUTO_INCREMENT,
  `cao_code` varchar(255) NOT NULL,
  `cao_yard` int(150) NOT NULL,
  `cao_from` varchar(255) NOT NULL,
  `cao_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autocao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='transection ผ้าดิบ';

--
-- Data for Table `calico_out`
--

/*!40000 ALTER TABLE `calico_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `calico_out` ENABLE KEYS */;


--
-- Create Table `dai`
--

DROP TABLE IF EXISTS `dai`;
CREATE TABLE `dai` (
  `id_autok` int(100) NOT NULL AUTO_INCREMENT,
  `k_code` varchar(255) NOT NULL,
  `k_color` varchar(150) NOT NULL,
  `k_from` varchar(255) NOT NULL,
  `k_number` int(100) NOT NULL,
  `k_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autok`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='ด้าย';

--
-- Data for Table `dai`
--

/*!40000 ALTER TABLE `dai` DISABLE KEYS */;
INSERT INTO `dai` (`id_autok`,`k_code`,`k_color`,`k_from`,`k_number`,`k_date`) VALUES ('1','dai1','red','kkk','10','2016/05/03 09:30');
/*!40000 ALTER TABLE `dai` ENABLE KEYS */;


--
-- Create Table `dai_out`
--

DROP TABLE IF EXISTS `dai_out`;
CREATE TABLE `dai_out` (
  `id_daio` int(100) NOT NULL AUTO_INCREMENT,
  `do_code` varchar(255) NOT NULL,
  `do_col` varchar(150) NOT NULL,
  `do_from` varchar(255) NOT NULL,
  `do_number` int(150) NOT NULL,
  `do_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_daio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='transection_out จำหน่ายด้าย';

--
-- Data for Table `dai_out`
--

/*!40000 ALTER TABLE `dai_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `dai_out` ENABLE KEYS */;


--
-- Create Table `fortnight`
--

DROP TABLE IF EXISTS `fortnight`;
CREATE TABLE `fortnight` (
  `f_picture` varchar(255) NOT NULL,
  `f_code` varchar(255) NOT NULL,
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_auto`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Data for Table `fortnight`
--

/*!40000 ALTER TABLE `fortnight` DISABLE KEYS */;
INSERT INTO `fortnight` (`f_picture`,`f_code`,`id_auto`) VALUES ('1012640_10205138695894162_3579677121630777410_n.jpg','pak1','1');
/*!40000 ALTER TABLE `fortnight` ENABLE KEYS */;


--
-- Create Table `gender`
--

DROP TABLE IF EXISTS `gender`;
CREATE TABLE `gender` (
  `id_gender` int(10) NOT NULL AUTO_INCREMENT,
  `sex` varchar(10) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_gender`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Data for Table `gender`
--

/*!40000 ALTER TABLE `gender` DISABLE KEYS */;
INSERT INTO `gender` (`id_gender`,`sex`) VALUES ('1','Male');
INSERT INTO `gender` (`id_gender`,`sex`) VALUES ('2','Female');
/*!40000 ALTER TABLE `gender` ENABLE KEYS */;


--
-- Create Table `jeans`
--

DROP TABLE IF EXISTS `jeans`;
CREATE TABLE `jeans` (
  `id_autojean` int(11) NOT NULL AUTO_INCREMENT,
  `je_code` varchar(255) NOT NULL,
  `je_yard` int(100) NOT NULL,
  `je_from` varchar(255) NOT NULL,
  `je_color` varchar(100) NOT NULL,
  `je_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autojean`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='ผ้ายีนส์';

--
-- Data for Table `jeans`
--

/*!40000 ALTER TABLE `jeans` DISABLE KEYS */;
INSERT INTO `jeans` (`id_autojean`,`je_code`,`je_yard`,`je_from`,`je_color`,`je_date`) VALUES ('2','je555','160','yyyyyy','ddd','2016/05/03 14:09');
/*!40000 ALTER TABLE `jeans` ENABLE KEYS */;


--
-- Create Table `jeans_out`
--

DROP TABLE IF EXISTS `jeans_out`;
CREATE TABLE `jeans_out` (
  `id_autoj` int(100) NOT NULL AUTO_INCREMENT,
  `jo_code` varchar(255) NOT NULL,
  `jo_yard` int(100) NOT NULL,
  `jo_from` varchar(255) NOT NULL,
  `jo_color` varchar(150) NOT NULL,
  `jo_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autoj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ตัดสต๊อกผ้ายีนส์และเก็บ Transection';

--
-- Data for Table `jeans_out`
--

/*!40000 ALTER TABLE `jeans_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `jeans_out` ENABLE KEYS */;


--
-- Create Table `leather`
--

DROP TABLE IF EXISTS `leather`;
CREATE TABLE `leather` (
  `id_autolea` int(100) NOT NULL AUTO_INCREMENT,
  `lea_code` varchar(255) NOT NULL,
  `lea_from` varchar(255) NOT NULL,
  `lea_number` int(200) NOT NULL,
  `lea_picture` varchar(255) NOT NULL,
  `lea_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autolea`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='ป้ายหนัง';

--
-- Data for Table `leather`
--

/*!40000 ALTER TABLE `leather` DISABLE KEYS */;
INSERT INTO `leather` (`id_autolea`,`lea_code`,`lea_from`,`lea_number`,`lea_picture`,`lea_date`) VALUES ('1','nun456','rrrr','456','1.jpg','2016/05/03 09:32');
/*!40000 ALTER TABLE `leather` ENABLE KEYS */;


--
-- Create Table `leather_out`
--

DROP TABLE IF EXISTS `leather_out`;
CREATE TABLE `leather_out` (
  `id_autoleao` int(100) NOT NULL AUTO_INCREMENT,
  `leao_code` varchar(255) NOT NULL,
  `leao_from` varchar(255) NOT NULL,
  `leao_number` int(200) NOT NULL,
  `leao_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autoleao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='transection ป้ายหนัง';

--
-- Data for Table `leather_out`
--

/*!40000 ALTER TABLE `leather_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `leather_out` ENABLE KEYS */;


--
-- Create Table `ordersell`
--

DROP TABLE IF EXISTS `ordersell`;
CREATE TABLE `ordersell` (
  `id_auto_order` int(10) NOT NULL AUTO_INCREMENT,
  `or_colpant` varchar(255) NOT NULL,
  `or_code` varchar(255) NOT NULL,
  `or_out` varchar(255) NOT NULL,
  `or_number` int(100) NOT NULL,
  `or_colfab` int(100) NOT NULL,
  `or_whifab` int(100) NOT NULL,
  `or_ku` int(100) NOT NULL,
  `or_tang` int(100) NOT NULL,
  `or_sum` int(100) NOT NULL,
  `or_type` varchar(255) NOT NULL,
  `or_codejean` varchar(255) NOT NULL,
  `or_tag` varchar(255) NOT NULL,
  `or_ps` varchar(255) NOT NULL,
  PRIMARY KEY (`id_auto_order`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='ใบสั่งตัด';

--
-- Data for Table `ordersell`
--

/*!40000 ALTER TABLE `ordersell` DISABLE KEYS */;
INSERT INTO `ordersell` (`id_auto_order`,`or_colpant`,`or_code`,`or_out`,`or_number`,`or_colfab`,`or_whifab`,`or_ku`,`or_tang`,`or_sum`,`or_type`,`or_codejean`,`or_tag`,`or_ps`) VALUES ('6','red','p123','feed','1','2','2','3','3','9','ขากระบอก','je555','wwww','www');
INSERT INTO `ordersell` (`id_auto_order`,`or_colpant`,`or_code`,`or_out`,`or_number`,`or_colfab`,`or_whifab`,`or_ku`,`or_tang`,`or_sum`,`or_type`,`or_codejean`,`or_tag`,`or_ps`) VALUES ('7','red','p123','feed','1','2','2','3','3','9','ขากระบอก','je555','wwww','www');
INSERT INTO `ordersell` (`id_auto_order`,`or_colpant`,`or_code`,`or_out`,`or_number`,`or_colfab`,`or_whifab`,`or_ku`,`or_tang`,`or_sum`,`or_type`,`or_codejean`,`or_tag`,`or_ps`) VALUES ('9','red','p123','feed','1','2','2','3','3','9','ขากระบอก','je555','wwww','www');
/*!40000 ALTER TABLE `ordersell` ENABLE KEYS */;


--
-- Create Table `pants`
--

DROP TABLE IF EXISTS `pants`;
CREATE TABLE `pants` (
  `id_auto_pants` int(100) NOT NULL AUTO_INCREMENT,
  `id_code_p` varchar(255) NOT NULL,
  `p_type` varchar(100) NOT NULL,
  `p_gender` varchar(100) NOT NULL,
  `p_s` int(255) NOT NULL,
  `p_m` int(255) NOT NULL,
  `p_l` int(255) NOT NULL,
  `p_xl` int(255) NOT NULL,
  `p_34` int(255) NOT NULL,
  `p_36` int(255) NOT NULL,
  `p_38` int(255) NOT NULL,
  `p_40` int(255) NOT NULL,
  `p_coly` varchar(255) NOT NULL,
  `p_colp` varchar(255) NOT NULL,
  `p_date` varchar(255) NOT NULL,
  `p_picture` varchar(255) NOT NULL,
  `p_code_pak` varchar(255) NOT NULL,
  PRIMARY KEY (`id_auto_pants`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='รายการกางเกง';

--
-- Data for Table `pants`
--

/*!40000 ALTER TABLE `pants` DISABLE KEYS */;
INSERT INTO `pants` (`id_auto_pants`,`id_code_p`,`p_type`,`p_gender`,`p_s`,`p_m`,`p_l`,`p_xl`,`p_34`,`p_36`,`p_38`,`p_40`,`p_coly`,`p_colp`,`p_date`,`p_picture`,`p_code_pak`) VALUES ('2','p789','4','Male','10','3','85','90','3','0','2','2','dark ','red','2016/05/14 22:42','25102011.jpg','pak1');
INSERT INTO `pants` (`id_auto_pants`,`id_code_p`,`p_type`,`p_gender`,`p_s`,`p_m`,`p_l`,`p_xl`,`p_34`,`p_36`,`p_38`,`p_40`,`p_coly`,`p_colp`,`p_date`,`p_picture`,`p_code_pak`) VALUES ('3','p123','1','Male','0','0','0','0','0','0','0','0','rr','rrr','2016/05/14 22:43','26102011.jpg','pak1');
INSERT INTO `pants` (`id_auto_pants`,`id_code_p`,`p_type`,`p_gender`,`p_s`,`p_m`,`p_l`,`p_xl`,`p_34`,`p_36`,`p_38`,`p_40`,`p_coly`,`p_colp`,`p_date`,`p_picture`,`p_code_pak`) VALUES ('11','p456','8','Female','0','1','1','1','6','1','1','1','h','jk','2016/05/14 23:04','26102011.jpg','pak1');
INSERT INTO `pants` (`id_auto_pants`,`id_code_p`,`p_type`,`p_gender`,`p_s`,`p_m`,`p_l`,`p_xl`,`p_34`,`p_36`,`p_38`,`p_40`,`p_coly`,`p_colp`,`p_date`,`p_picture`,`p_code_pak`) VALUES ('12','p780','8','Female','1','1','1','1','7','1','1','1','h','jk','2016/05/14 23:04','26102011.jpg','pak1');
/*!40000 ALTER TABLE `pants` ENABLE KEYS */;


--
-- Create Table `sell_pants`
--

DROP TABLE IF EXISTS `sell_pants`;
CREATE TABLE `sell_pants` (
  `id_auto_sellpant` int(100) NOT NULL AUTO_INCREMENT,
  `sellpa_codel` varchar(255) NOT NULL,
  `sellpa_shop` varchar(255) NOT NULL,
  `sellpa_address` varchar(255) NOT NULL,
  `sellpa_date` varchar(100) NOT NULL,
  `sellpa_ss` int(100) NOT NULL,
  `sellpa_sm` int(100) NOT NULL,
  `sellpa_sl` int(100) NOT NULL,
  `sellpa_sxl` int(100) NOT NULL,
  `sellpa_s34` int(100) NOT NULL,
  `sellpa_s36` int(100) NOT NULL,
  `sellpa_s38` int(100) NOT NULL,
  `sellpa_s40` int(100) NOT NULL,
  PRIMARY KEY (`id_auto_sellpant`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='transection การขายกางเกง';

--
-- Data for Table `sell_pants`
--

/*!40000 ALTER TABLE `sell_pants` DISABLE KEYS */;
INSERT INTO `sell_pants` (`id_auto_sellpant`,`sellpa_codel`,`sellpa_shop`,`sellpa_address`,`sellpa_date`,`sellpa_ss`,`sellpa_sm`,`sellpa_sl`,`sellpa_sxl`,`sellpa_s34`,`sellpa_s36`,`sellpa_s38`,`sellpa_s40`) VALUES ('5','p780','44','กดเดก','2016/05/15 11:31','0','0','0','0','2','0','0','0');
INSERT INTO `sell_pants` (`id_auto_sellpant`,`sellpa_codel`,`sellpa_shop`,`sellpa_address`,`sellpa_date`,`sellpa_ss`,`sellpa_sm`,`sellpa_sl`,`sellpa_sxl`,`sellpa_s34`,`sellpa_s36`,`sellpa_s38`,`sellpa_s40`) VALUES ('8','p111','44','กดเดก','2016/05/15 19:19','1','0','1','0','0','1','0','0');
INSERT INTO `sell_pants` (`id_auto_sellpant`,`sellpa_codel`,`sellpa_shop`,`sellpa_address`,`sellpa_date`,`sellpa_ss`,`sellpa_sm`,`sellpa_sl`,`sellpa_sxl`,`sellpa_s34`,`sellpa_s36`,`sellpa_s38`,`sellpa_s40`) VALUES ('9','p789','กกน','','2016/05/15 19:25','1','1','3','5','1','3','1','1');
INSERT INTO `sell_pants` (`id_auto_sellpant`,`sellpa_codel`,`sellpa_shop`,`sellpa_address`,`sellpa_date`,`sellpa_ss`,`sellpa_sm`,`sellpa_sl`,`sellpa_sxl`,`sellpa_s34`,`sellpa_s36`,`sellpa_s38`,`sellpa_s40`) VALUES ('10','p789','กกน','','2016/05/15 19:25','1','1','1','1','2','0','2','2');
INSERT INTO `sell_pants` (`id_auto_sellpant`,`sellpa_codel`,`sellpa_shop`,`sellpa_address`,`sellpa_date`,`sellpa_ss`,`sellpa_sm`,`sellpa_sl`,`sellpa_sxl`,`sellpa_s34`,`sellpa_s36`,`sellpa_s38`,`sellpa_s40`) VALUES ('12','p123','44','กดเดก','2016/05/15 20:43','0','0','0','0','0','0','0','0');
INSERT INTO `sell_pants` (`id_auto_sellpant`,`sellpa_codel`,`sellpa_shop`,`sellpa_address`,`sellpa_date`,`sellpa_ss`,`sellpa_sm`,`sellpa_sl`,`sellpa_sxl`,`sellpa_s34`,`sellpa_s36`,`sellpa_s38`,`sellpa_s40`) VALUES ('13','p789','12315','กกก','2016/05/16 07:43','0','0','0','0','0','0','0','0');
/*!40000 ALTER TABLE `sell_pants` ENABLE KEYS */;


--
-- Create Table `sell_pantsprice`
--

DROP TABLE IF EXISTS `sell_pantsprice`;
CREATE TABLE `sell_pantsprice` (
  `id_auto_spp` int(100) NOT NULL AUTO_INCREMENT,
  `spp_code` varchar(255) NOT NULL,
  `spp_sp` int(100) NOT NULL,
  `spp_mp` int(100) NOT NULL,
  `spp_lp` int(100) NOT NULL,
  `spp_xlp` int(100) NOT NULL,
  `spp_34p` int(100) NOT NULL,
  `spp_36p` int(100) NOT NULL,
  `spp_38p` int(100) NOT NULL,
  `spp_40p` int(100) NOT NULL,
  `spp_discount` int(100) NOT NULL,
  `spp_total` int(100) NOT NULL,
  `sp_shopname` varchar(255) NOT NULL,
  PRIMARY KEY (`id_auto_spp`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='transection ราคาขายกางเกง';

--
-- Data for Table `sell_pantsprice`
--

/*!40000 ALTER TABLE `sell_pantsprice` DISABLE KEYS */;
INSERT INTO `sell_pantsprice` (`id_auto_spp`,`spp_code`,`spp_sp`,`spp_mp`,`spp_lp`,`spp_xlp`,`spp_34p`,`spp_36p`,`spp_38p`,`spp_40p`,`spp_discount`,`spp_total`,`sp_shopname`) VALUES ('5','p780','0','0','0','0','2','0','0','0','2','2','44');
INSERT INTO `sell_pantsprice` (`id_auto_spp`,`spp_code`,`spp_sp`,`spp_mp`,`spp_lp`,`spp_xlp`,`spp_34p`,`spp_36p`,`spp_38p`,`spp_40p`,`spp_discount`,`spp_total`,`sp_shopname`) VALUES ('8','p111','1','0','1','0','0','1','0','0','1','2','44');
INSERT INTO `sell_pantsprice` (`id_auto_spp`,`spp_code`,`spp_sp`,`spp_mp`,`spp_lp`,`spp_xlp`,`spp_34p`,`spp_36p`,`spp_38p`,`spp_40p`,`spp_discount`,`spp_total`,`sp_shopname`) VALUES ('9','p789','10','20','22','66','22','3','12','21','10','480','กกน');
INSERT INTO `sell_pantsprice` (`id_auto_spp`,`spp_code`,`spp_sp`,`spp_mp`,`spp_lp`,`spp_xlp`,`spp_34p`,`spp_36p`,`spp_38p`,`spp_40p`,`spp_discount`,`spp_total`,`sp_shopname`) VALUES ('10','p789','12','12','21','23','3','0','2','2','2','80','กกน');
INSERT INTO `sell_pantsprice` (`id_auto_spp`,`spp_code`,`spp_sp`,`spp_mp`,`spp_lp`,`spp_xlp`,`spp_34p`,`spp_36p`,`spp_38p`,`spp_40p`,`spp_discount`,`spp_total`,`sp_shopname`) VALUES ('12','p123','0','0','0','0','0','0','0','0','0','0','44');
INSERT INTO `sell_pantsprice` (`id_auto_spp`,`spp_code`,`spp_sp`,`spp_mp`,`spp_lp`,`spp_xlp`,`spp_34p`,`spp_36p`,`spp_38p`,`spp_40p`,`spp_discount`,`spp_total`,`sp_shopname`) VALUES ('13','p789','0','0','0','0','0','0','0','0','0','0','12315');
/*!40000 ALTER TABLE `sell_pantsprice` ENABLE KEYS */;


--
-- Create Table `shop`
--

DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop` (
  `id_shop` int(100) NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `shop_pcode` varchar(255) NOT NULL,
  PRIMARY KEY (`id_shop`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='detail shop';

--
-- Data for Table `shop`
--

/*!40000 ALTER TABLE `shop` DISABLE KEYS */;
INSERT INTO `shop` (`id_shop`,`shop_name`,`address`,`shop_pcode`) VALUES ('1','44','กดเดก','p1233,p111,p780,p780');
INSERT INTO `shop` (`id_shop`,`shop_name`,`address`,`shop_pcode`) VALUES ('2','กกน','','p789');
INSERT INTO `shop` (`id_shop`,`shop_name`,`address`,`shop_pcode`) VALUES ('3','44','กดเดก','p123');
INSERT INTO `shop` (`id_shop`,`shop_name`,`address`,`shop_pcode`) VALUES ('4','12313','1256','p789');
INSERT INTO `shop` (`id_shop`,`shop_name`,`address`,`shop_pcode`) VALUES ('5','นนน','กกก','p789');
INSERT INTO `shop` (`id_shop`,`shop_name`,`address`,`shop_pcode`) VALUES ('6','12315','กกก','p789');
/*!40000 ALTER TABLE `shop` ENABLE KEYS */;


--
-- Create Table `studs`
--

DROP TABLE IF EXISTS `studs`;
CREATE TABLE `studs` (
  `id_autost` int(100) NOT NULL AUTO_INCREMENT,
  `st_code` varchar(255) NOT NULL,
  `st_from` varchar(255) NOT NULL,
  `st_number` int(200) NOT NULL,
  `st_picture` varchar(255) NOT NULL,
  `st_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autost`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='กะระดุม';

--
-- Data for Table `studs`
--

/*!40000 ALTER TABLE `studs` DISABLE KEYS */;
INSERT INTO `studs` (`id_autost`,`st_code`,`st_from`,`st_number`,`st_picture`,`st_date`) VALUES ('1','dum1','ggg','10','97875-bigthumbnail.jpg','2016/05/02 08:59');
/*!40000 ALTER TABLE `studs` ENABLE KEYS */;


--
-- Create Table `studs_out`
--

DROP TABLE IF EXISTS `studs_out`;
CREATE TABLE `studs_out` (
  `id_autosto` int(100) NOT NULL AUTO_INCREMENT,
  `sto_code` varchar(255) NOT NULL,
  `sto_from` varchar(255) NOT NULL,
  `sto_number` int(200) NOT NULL,
  `sto_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autosto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='transection จำหน่ยกระดุม';

--
-- Data for Table `studs_out`
--

/*!40000 ALTER TABLE `studs_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `studs_out` ENABLE KEYS */;


--
-- Create Table `tag_paper`
--

DROP TABLE IF EXISTS `tag_paper`;
CREATE TABLE `tag_paper` (
  `id_autotagp` int(100) NOT NULL AUTO_INCREMENT,
  `tp_code` varchar(255) NOT NULL,
  `tp_fromshop` varchar(255) NOT NULL,
  `tp_number` int(200) NOT NULL,
  `tp_picture` varchar(255) NOT NULL,
  `tp_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autotagp`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='ป้ายกระดาษ';

--
-- Data for Table `tag_paper`
--

/*!40000 ALTER TABLE `tag_paper` DISABLE KEYS */;
INSERT INTO `tag_paper` (`id_autotagp`,`tp_code`,`tp_fromshop`,`tp_number`,`tp_picture`,`tp_date`) VALUES ('3','pa789','rrrrrrrrrrr','456','10606496_972538942786451_431905095567247987_n.jpg','2016/05/03 14:22');
/*!40000 ALTER TABLE `tag_paper` ENABLE KEYS */;


--
-- Create Table `tag_paper_out`
--

DROP TABLE IF EXISTS `tag_paper_out`;
CREATE TABLE `tag_paper_out` (
  `id_auto_po` int(100) NOT NULL AUTO_INCREMENT,
  `tp_code` varchar(255) NOT NULL,
  `tp_number` int(150) NOT NULL,
  `tp_date` varchar(255) NOT NULL,
  PRIMARY KEY (`id_auto_po`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='transection_out ป้ายกระดาษ';

--
-- Data for Table `tag_paper_out`
--

/*!40000 ALTER TABLE `tag_paper_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_paper_out` ENABLE KEYS */;


--
-- Create Table `type_pants`
--

DROP TABLE IF EXISTS `type_pants`;
CREATE TABLE `type_pants` (
  `id_pants` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_pants`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COMMENT='ประเภทกางเกง';

--
-- Data for Table `type_pants`
--

/*!40000 ALTER TABLE `type_pants` DISABLE KEYS */;
INSERT INTO `type_pants` (`id_pants`,`type`) VALUES ('1','ขาเดฟ');
INSERT INTO `type_pants` (`id_pants`,`type`) VALUES ('2','ขากระบอก');
INSERT INTO `type_pants` (`id_pants`,`type`) VALUES ('3','ขา 3 ส่วน');
INSERT INTO `type_pants` (`id_pants`,`type`) VALUES ('4','ขา 5 ส่วน');
INSERT INTO `type_pants` (`id_pants`,`type`) VALUES ('5','ขาม้า');
INSERT INTO `type_pants` (`id_pants`,`type`) VALUES ('6','ขาสั้น');
INSERT INTO `type_pants` (`id_pants`,`type`) VALUES ('7','กระโปรงยาว');
INSERT INTO `type_pants` (`id_pants`,`type`) VALUES ('8','กระโปรงสั้น');
/*!40000 ALTER TABLE `type_pants` ENABLE KEYS */;


--
-- Create Table `zip`
--

DROP TABLE IF EXISTS `zip`;
CREATE TABLE `zip` (
  `id_autoz` int(100) NOT NULL AUTO_INCREMENT,
  `z_code` varchar(255) NOT NULL,
  `z_from` varchar(255) NOT NULL,
  `z_number` int(200) NOT NULL,
  `z_picture` varchar(255) NOT NULL,
  `z_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autoz`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='ซิป';

--
-- Data for Table `zip`
--

/*!40000 ALTER TABLE `zip` DISABLE KEYS */;
INSERT INTO `zip` (`id_autoz`,`z_code`,`z_from`,`z_number`,`z_picture`,`z_date`) VALUES ('1','zip','ggg','12','7437_20100917p1.jpg','2016/05/03 09:30');
/*!40000 ALTER TABLE `zip` ENABLE KEYS */;


--
-- Create Table `zip_out`
--

DROP TABLE IF EXISTS `zip_out`;
CREATE TABLE `zip_out` (
  `id_autozo` int(100) NOT NULL AUTO_INCREMENT,
  `zo_code` varchar(255) NOT NULL,
  `zo_from` varchar(255) NOT NULL,
  `zo_number` int(200) NOT NULL,
  `zo_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id_autozo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='transection จำหน่ายซิป';

--
-- Data for Table `zip_out`
--

/*!40000 ALTER TABLE `zip_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `zip_out` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

